import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;

public class Pet_Adoption extends JDialog {
    int count=0, xrow=0;
    String name=" ", gender=" ", coursegrade=" ", studentNumber;
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JTabbedPane tabbedPane1;
    private JTextField txtPetName;
    private JTextField txtBreed;
    private JCheckBox chkMale;
    private JCheckBox chkFemale;
    private JTextField txtColor;
    private JTextField txtHealthStatus;
    private JComboBox cmbPetList;
    private JTextArea txtPetInformation;
    private JButton btnAddPet;
    private JButton btnCancel;
    private JTable table1;
    private JTextField txtLastName;
    private JTextField txtFirstName;
    private JTextField txtAddress;
    private JTextField txtPhone;
    private JTextField txtEmail;
    private JCheckBox chkApartment;
    private JCheckBox chkHouse;
    private JCheckBox chkRent;
    private JCheckBox chkYes;
    private JCheckBox chkNo;
    private JTextField txtOwnedPets;
    private JButton btnSave;
    private JCheckBox chkCondo;
    private JComboBox cmbSpecie;

    public Pet_Adoption() {
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(btnSave);

        table1.setModel(new DefaultTableModel(
                null,
                new String[] {"Pet Name","Breed","Color", "Specie", "Gender", "Health Status"}
        ));

        btnAddPet.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onADD();
            }
        });

        btnSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onSAVE();
            }
        });
        chkFemale.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addFemale();
            }
        });
        chkMale.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addMale();
            }
        });

        buttonCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        // call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }
    private void addFemale()
    {
        gender="F";
        chkMale.setSelected(false);
    }

    private void addMale()
    {
        gender="M";
        chkFemale.setSelected(false);
    }

    private void onADD() {
        DefaultTableModel studentList = (DefaultTableModel)
                table1.getModel();
        name = txtPetName.getText();
        count++;
        String petName = name.toUpperCase();
        String petBreed = txtBreed.getText();
        String petColor = txtColor.getText();
        String petSpecie = cmbSpecie.getSelectedItem().toString();
        String petGender = gender;
        String petHealth = txtHealthStatus.getText();
        //identify the values to be stored in the table
        Object[] row = {count, petName, petBreed,
                petColor, petSpecie, petGender, petHealth};
        //add values to the table row
        studentList.addRow(row);
        //insert studentName in the combo box located in GRADE tab

        cmbPetList.insertItemAt(studentList.getValueAt(xrow,1).toString(),xrow);
        xrow++;
    }

    private void onSAVE() {
        // add your code here
        dispose();
    }

    private void onCancel() {
        // add your code here if necessary
        dispose();
    }

    public static void main(String[] args) {
        Pet_Adoption dialog = new Pet_Adoption();
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }

}
